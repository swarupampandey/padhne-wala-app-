import { Router, type IRouter } from "express";
import { AiExtractQuestionBody, AiGenerateImageBody, AiChatBody } from "@workspace/api-zod";

const router: IRouter = Router();

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const TOGETHER_AI_API_KEY = process.env.TOGETHER_AI_API_KEY;

// ── Gemini helpers ──────────────────────────────────────────────────────────
async function geminiChat(systemContext: string, history: any[], userMessage: string, apiKey: string): Promise<string> {
  const contents = [
    { role: "user", parts: [{ text: systemContext }] },
    { role: "model", parts: [{ text: "Ready to help! What would you like to know?" }] },
    ...(history || []).map((m: any) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })),
    { role: "user", parts: [{ text: userMessage }] },
  ];
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents, generationConfig: { temperature: 0.7, maxOutputTokens: 1024 } }),
  });
  if (!res.ok) throw new Error(`Gemini error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "I couldn't generate a response.";
}

async function geminiExtract(parts: any[], apiKey: string): Promise<any> {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ parts }], generationConfig: { temperature: 0.1, maxOutputTokens: 2048 } }),
  });
  if (!res.ok) throw new Error(`Gemini error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("Gemini returned no JSON");
  return JSON.parse(match[0]);
}

async function geminiOcr(parts: any[], apiKey: string): Promise<string> {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ parts }], generationConfig: { temperature: 0.0, maxOutputTokens: 2048 } }),
  });
  if (!res.ok) throw new Error(`Gemini OCR error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  return data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ?? "";
}

// ── OpenAI helpers ──────────────────────────────────────────────────────────
async function openaiChat(system: string, history: any[], userMessage: string, apiKey: string, model: string): Promise<string> {
  const messages = [
    { role: "system", content: system },
    ...(history || []).map((m: any) => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.content })),
    { role: "user", content: userMessage },
  ];
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: model || "gpt-4o-mini", messages, max_tokens: 1024, temperature: 0.7 }),
  });
  if (!res.ok) throw new Error(`OpenAI error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  return data.choices?.[0]?.message?.content ?? "No response.";
}

async function openaiExtract(system: string, userContent: any[], apiKey: string, model: string): Promise<any> {
  const visionModel = model.includes("4o") ? model : "gpt-4o-mini";
  const messages: any[] = [
    { role: "system", content: system },
    { role: "user", content: userContent.some(c => c.type === "image_url") ? userContent : (userContent.find((c: any) => c.type === "text")?.text ?? "") },
  ];
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: visionModel, messages, max_tokens: 2048, temperature: 0.1 }),
  });
  if (!res.ok) throw new Error(`OpenAI error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  const text = data.choices?.[0]?.message?.content ?? "";
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("OpenAI returned no JSON");
  return JSON.parse(match[0]);
}

async function openaiOcr(userContent: any[], apiKey: string, model: string): Promise<string> {
  const visionModel = model.includes("4o") ? model : "gpt-4o-mini";
  const messages: any[] = [
    { role: "system", content: "Extract all visible text from the image or PDF. Return only plain text with no markdown, labels, or commentary." },
    { role: "user", content: userContent },
  ];
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: visionModel, messages, max_tokens: 2048, temperature: 0.0 }),
  });
  if (!res.ok) throw new Error(`OpenAI OCR error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  return data.choices?.[0]?.message?.content?.trim() ?? "";
}

// ── Azure OpenAI helpers ────────────────────────────────────────────────────
async function azureChat(system: string, history: any[], userMessage: string, apiKey: string, endpoint: string, deployment: string): Promise<string> {
  const messages = [
    { role: "system", content: system },
    ...(history || []).map((m: any) => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.content })),
    { role: "user", content: userMessage },
  ];
  const url = `${endpoint.replace(/\/$/, "")}/openai/deployments/${deployment}/chat/completions?api-version=2024-02-15-preview`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "api-key": apiKey },
    body: JSON.stringify({ messages, max_tokens: 1024, temperature: 0.7 }),
  });
  if (!res.ok) throw new Error(`Azure error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  return data.choices?.[0]?.message?.content ?? "No response.";
}

async function azureExtract(system: string, userText: string, apiKey: string, endpoint: string, deployment: string): Promise<any> {
  const url = `${endpoint.replace(/\/$/, "")}/openai/deployments/${deployment}/chat/completions?api-version=2024-02-15-preview`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "api-key": apiKey },
    body: JSON.stringify({ messages: [{ role: "system", content: system }, { role: "user", content: userText }], max_tokens: 2048, temperature: 0.1 }),
  });
  if (!res.ok) throw new Error(`Azure error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  const text = data.choices?.[0]?.message?.content ?? "";
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("Azure returned no JSON");
  return JSON.parse(match[0]);
}

async function azureOcr(userContent: any[], apiKey: string, endpoint: string, deployment: string): Promise<string> {
  const url = `${endpoint.replace(/\/$/, "")}/openai/deployments/${deployment}/chat/completions?api-version=2024-02-15-preview`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "api-key": apiKey },
    body: JSON.stringify({ messages: [{ role: "system", content: "Extract all visible text from the image or PDF. Return only plain text with no labels or formatting." }, { role: "user", content: userContent }], max_tokens: 2048, temperature: 0.0 }),
  });
  if (!res.ok) throw new Error(`Azure OCR error ${res.status}: ${await res.text()}`);
  const data = await res.json() as any;
  return data.choices?.[0]?.message?.content?.trim() ?? "";
}

const EXTRACT_JSON_SCHEMA = `Return ONLY a valid JSON object:
{
  "originalText": "full question text",
  "options": ["option A", "option B", "option C", "option D"],
  "correctAnswer": 0,
  "explanation": "detailed explanation",
  "imageGenPrompt": "diagram description without text labels, or null",
  "subject": "Physics|Chemistry|Biology",
  "chapter": "chapter name",
  "topic": "specific topic"
}
Rules: correctAnswer is 0-indexed. Return ONLY JSON, no markdown.`;

router.post("/ai/extract", async (req, res): Promise<void> => {
  const parsed = AiExtractQuestionBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { imageBase64, mimeType, rawText, subject, chapter } = parsed.data;
  const activeModel = (req.headers["x-active-model"] as string) || "gemini";
  const openaiKey = req.headers["x-openai-key"] as string;
  const openaiModel = (req.headers["x-openai-model"] as string) || "gpt-4o-mini";
  const azureKey = req.headers["x-azure-key"] as string;
  const azureEndpoint = req.headers["x-azure-endpoint"] as string;
  const azureDeployment = req.headers["x-azure-deployment"] as string;

  const ctxHint = [subject ? `Subject: ${subject}` : "", chapter ? `Chapter: ${chapter}` : ""].filter(Boolean).join(". ");

  try {
    let extracted: any;
    if (activeModel === "openai" && openaiKey) {
      const userContent: any[] = [];
      if (imageBase64 && mimeType) userContent.push({ type: "image_url", image_url: { url: `data:${mimeType};base64,${imageBase64}`, detail: "high" } });
      userContent.push({ type: "text", text: (rawText ? `Extract NEET MCQ from:\n${rawText}` : "Extract the NEET MCQ from the image.") + (ctxHint ? `\n${ctxHint}` : "") });
      extracted = await openaiExtract(EXTRACT_JSON_SCHEMA, userContent, openaiKey, openaiModel);
    } else if (activeModel === "azure" && azureKey && azureEndpoint && azureDeployment) {
      const userText = (rawText ? `Extract NEET MCQ from:\n${rawText}` : "Extract the NEET MCQ.") + (ctxHint ? `\n${ctxHint}` : "");
      extracted = await azureExtract(EXTRACT_JSON_SCHEMA, userText, azureKey, azureEndpoint, azureDeployment);
    } else {
      if (!GEMINI_API_KEY) { res.status(500).json({ error: "GEMINI_API_KEY not configured. Add in Secrets or configure OpenAI/Azure in Settings." }); return; }
      const parts: any[] = [];
      if (imageBase64 && mimeType) parts.push({ inline_data: { mime_type: mimeType, data: imageBase64 } });
      const prompt = (rawText ? `Analyze this NEET MCQ text:\n${rawText}` : "Analyze this NEET question image.") + (ctxHint ? `\n${ctxHint}` : "") + `\n\n${EXTRACT_JSON_SCHEMA}`;
      parts.push({ text: prompt });
      extracted = await geminiExtract(parts, GEMINI_API_KEY);
    }
    res.json(extracted);
  } catch (err: any) {
    req.log.error({ err }, "AI extract error");
    res.status(502).json({ error: err?.message || "Extraction failed. Check AI Settings." });
  }
});

router.post("/ai/generate-image", async (req, res): Promise<void> => {
  const parsed = AiGenerateImageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (!TOGETHER_AI_API_KEY) {
    res.status(500).json({ error: "TOGETHER_AI_API_KEY not configured" });
    return;
  }

  const { prompt } = parsed.data;

  try {
    const response = await fetch("https://api.together.xyz/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${TOGETHER_AI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "stabilityai/stable-diffusion-xl-base-1.0",
        prompt: `Scientific educational diagram: ${prompt}. Clean white background, no text labels, high quality, detailed.`,
        n: 1,
        width: 512,
        height: 512,
        steps: 20,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      req.log.error({ status: response.status, err }, "Together AI error");
      res.status(502).json({ error: `Together AI error: ${response.status}` });
      return;
    }

    const data = await response.json() as any;
    const imageUrl = data?.data?.[0]?.url ?? data?.data?.[0]?.b64_json;

    if (!imageUrl) {
      res.status(502).json({ error: "No image returned from Together AI" });
      return;
    }

    // If b64_json, wrap as data URL
    const finalUrl = imageUrl.startsWith("http")
      ? imageUrl
      : `data:image/png;base64,${imageUrl}`;

    res.json({ imageUrl: finalUrl });
  } catch (err) {
    req.log.error({ err }, "Image generation error");
    res.status(500).json({ error: "Image generation failed" });
  }
});

router.post("/ai/ocr", async (req, res): Promise<void> => {
  const parsed = AiExtractQuestionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { imageBase64, mimeType } = parsed.data;
  if (!imageBase64 || !mimeType) {
    res.status(400).json({ error: "imageBase64 and mimeType are required for OCR." });
    return;
  }

  const activeModel = (req.headers["x-active-model"] as string) || "gemini";
  const openaiKey = req.headers["x-openai-key"] as string;
  const openaiModel = (req.headers["x-openai-model"] as string) || "gpt-4o-mini";
  const azureKey = req.headers["x-azure-key"] as string;
  const azureEndpoint = req.headers["x-azure-endpoint"] as string;
  const azureDeployment = req.headers["x-azure-deployment"] as string;

  try {
    let text: string;

    if (activeModel === "openai" && openaiKey) {
      const userContent: any[] = [{ type: "image_url", image_url: { url: `data:${mimeType};base64,${imageBase64}`, detail: "high" } }];
      text = await openaiOcr(userContent, openaiKey, openaiModel);
    } else if (activeModel === "azure" && azureKey && azureEndpoint && azureDeployment) {
      const userContent: any[] = [{ type: "image_url", image_url: { url: `data:${mimeType};base64,${imageBase64}`, detail: "high" } }];
      text = await azureOcr(userContent, azureKey, azureEndpoint, azureDeployment);
    } else {
      if (!GEMINI_API_KEY) {
        res.status(500).json({ error: "GEMINI_API_KEY not configured. Add in Secrets or configure OpenAI/Azure in Settings." });
        return;
      }
      const parts: any[] = [
        { inline_data: { mime_type: mimeType, data: imageBase64 } },
        { text: "Extract all visible text from the uploaded file. Return only plain text, no markup." },
      ];
      text = await geminiOcr(parts, GEMINI_API_KEY);
    }

    res.json({ text: text.trim() });
  } catch (err: any) {
    req.log.error({ err }, "AI OCR error");
    res.status(502).json({ error: err?.message || "OCR failed. Check AI settings." });
  }
});

router.post("/ai/chat", async (req, res): Promise<void> => {
  const parsed = AiChatBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { questionText, options, correctAnswer, explanation, userMessage, history } = parsed.data;
  const activeModel = (req.headers["x-active-model"] as string) || "gemini";
  const openaiKey = req.headers["x-openai-key"] as string;
  const openaiModel = (req.headers["x-openai-model"] as string) || "gpt-4o-mini";
  const azureKey = req.headers["x-azure-key"] as string;
  const azureEndpoint = req.headers["x-azure-endpoint"] as string;
  const azureDeployment = req.headers["x-azure-deployment"] as string;

  const system = `You are an expert NEET tutor (Biology, Physics, Chemistry). Help the student understand this MCQ:

Question: ${questionText}
Options:
${options.map((o, i) => `${String.fromCharCode(65 + i)}. ${o}`).join("\n")}
Correct Answer: ${String.fromCharCode(65 + correctAnswer)} — ${options[correctAnswer]}
${explanation ? `Explanation: ${explanation}` : ""}

Be concise, clear, exam-focused. Use simple notation for formulas. Keep responses under 200 words unless asked for more.`;

  try {
    let reply: string;
    if (activeModel === "openai" && openaiKey) {
      reply = await openaiChat(system, history || [], userMessage, openaiKey, openaiModel);
    } else if (activeModel === "azure" && azureKey && azureEndpoint && azureDeployment) {
      reply = await azureChat(system, history || [], userMessage, azureKey, azureEndpoint, azureDeployment);
    } else {
      if (!GEMINI_API_KEY) { res.status(500).json({ error: "No AI configured. Add GEMINI_API_KEY in Secrets or set up OpenAI/Azure in Settings." }); return; }
      reply = await geminiChat(system, history || [], userMessage, GEMINI_API_KEY);
    }
    res.json({ reply });
  } catch (err: any) {
    req.log.error({ err }, "AI chat error");
    res.status(502).json({ error: err?.message || "Chat failed. Check AI Settings." });
  }
});

export default router;
