import { Router, type IRouter } from "express";
import healthRouter from "./health";
import questionsRouter from "./questions";
import weakAreasRouter from "./weak-areas";
import practiceRouter from "./practice";
import aiRouter from "./ai";
import studybloomRouter from "./studybloom";

const router: IRouter = Router();

router.use(healthRouter);
router.use(questionsRouter);
router.use(weakAreasRouter);
router.use(practiceRouter);
router.use(aiRouter);
router.use(studybloomRouter);

export default router;
