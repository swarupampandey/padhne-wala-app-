import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, questionsTable, weakAreasTable } from "@workspace/db";
import {
  StartPracticeSessionBody,
  SubmitPracticeAnswerBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/practice/start", async (req, res): Promise<void> => {
  const parsed = StartPracticeSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { subjectChapters, limit } = parsed.data;

  if (!subjectChapters.length) {
    res.status(400).json({ error: "No subject/chapters selected" });
    return;
  }

  // Fetch questions from any of the selected subject+chapter combos
  const questions = await db.select().from(questionsTable);
  const filtered = questions.filter(q =>
    subjectChapters.some(sc => sc.subject === q.subject && sc.chapter === q.chapter)
  );

  // Shuffle and limit
  const shuffled = filtered.sort(() => Math.random() - 0.5).slice(0, limit ?? 20);

  res.json(shuffled.map(q => ({
    ...q,
    options: q.options as string[],
    createdAt: q.createdAt.toISOString(),
  })));
});

router.post("/practice/submit", async (req, res): Promise<void> => {
  const parsed = SubmitPracticeAnswerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { questionId, selectedAnswer, userId } = parsed.data;

  const [q] = await db.select().from(questionsTable).where(eq(questionsTable.id, questionId));
  if (!q) {
    res.status(404).json({ error: "Question not found" });
    return;
  }

  const correct = selectedAnswer === q.correctAnswer;
  let weakAreaId: number | null = null;

  if (!correct) {
    // Check if already in weak areas for this user+question
    const existing = await db
      .select()
      .from(weakAreasTable)
      .where(
        userId
          ? and(eq(weakAreasTable.questionId, questionId), eq(weakAreasTable.userId, userId))
          : eq(weakAreasTable.questionId, questionId)
      );

    if (existing.length === 0) {
      const [wa] = await db.insert(weakAreasTable).values({
        questionId,
        userId: userId ?? null,
        subject: q.subject,
        chapter: q.chapter,
        resolved: false,
      }).returning();
      weakAreaId = wa.id;
    } else {
      weakAreaId = existing[0].id;
    }
  }

  res.json({
    correct,
    correctAnswer: q.correctAnswer,
    explanation: q.explanation,
    weakAreaId,
  });
});

export default router;
