import { Router, type IRouter } from "express";
import { eq, ilike, and, sql } from "drizzle-orm";
import { db, questionsTable } from "@workspace/db";
import {
  ListQuestionsQueryParams,
  CreateQuestionBody,
  GetQuestionParams,
  GetQuestionResponse,
  UpdateQuestionParams,
  UpdateQuestionBody,
  DeleteQuestionParams,
  ListQuestionsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/questions", async (req, res): Promise<void> => {
  const parsed = ListQuestionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { subject, chapter, topic, search } = parsed.data;
  const source = typeof req.query.source === "string" ? req.query.source : null;
  const conditions = [];
  if (subject) conditions.push(eq(questionsTable.subject, subject));
  if (chapter) conditions.push(eq(questionsTable.chapter, chapter));
  if (topic) conditions.push(eq(questionsTable.topic, topic));
  if (search) conditions.push(ilike(questionsTable.originalText, `%${search}%`));
  if (source === "main") conditions.push(sql`${questionsTable.userId} IS NULL`);
  if (source === "mine") conditions.push(sql`${questionsTable.userId} IS NOT NULL`);

  const rows = await db
    .select()
    .from(questionsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(questionsTable.createdAt);

  res.json(ListQuestionsResponse.parse(rows.map(q => ({
    ...q,
    options: q.options as string[],
    createdAt: q.createdAt.toISOString(),
  }))));
});

router.post("/questions", async (req, res): Promise<void> => {
  const parsed = CreateQuestionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [q] = await db.insert(questionsTable).values(parsed.data).returning();
  res.status(201).json(GetQuestionResponse.parse({
    ...q,
    options: q.options as string[],
    createdAt: q.createdAt.toISOString(),
  }));
});

router.get("/questions/subjects", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      subject: questionsTable.subject,
      chapter: questionsTable.chapter,
      topic: questionsTable.topic,
    })
    .from(questionsTable)
    .orderBy(questionsTable.subject, questionsTable.chapter);

  // Build tree
  const treeMap: Record<string, Record<string, Set<string>>> = {};
  const countMap: Record<string, Record<string, number>> = {};
  const subjectCount: Record<string, number> = {};

  for (const row of rows) {
    if (!treeMap[row.subject]) {
      treeMap[row.subject] = {};
      countMap[row.subject] = {};
      subjectCount[row.subject] = 0;
    }
    if (!treeMap[row.subject][row.chapter]) {
      treeMap[row.subject][row.chapter] = new Set();
      countMap[row.subject][row.chapter] = 0;
    }
    if (row.topic) treeMap[row.subject][row.chapter].add(row.topic);
    countMap[row.subject][row.chapter]++;
    subjectCount[row.subject]++;
  }

  const tree = Object.entries(treeMap).map(([subject, chapters]) => ({
    subject,
    count: subjectCount[subject],
    chapters: Object.entries(chapters).map(([chapter, topics]) => ({
      chapter,
      count: countMap[subject][chapter],
      topics: Array.from(topics),
    })),
  }));

  res.json(tree);
});

router.get("/questions/stats", async (_req, res): Promise<void> => {
  const rows = await db.select({ subject: questionsTable.subject }).from(questionsTable);
  const bySubject: Record<string, number> = {};
  for (const r of rows) {
    bySubject[r.subject] = (bySubject[r.subject] || 0) + 1;
  }

  const recentCount = await db
    .select({ count: sql<number>`count(*)` })
    .from(questionsTable)
    .where(sql`created_at > now() - interval '7 days'`);

  res.json({
    total: rows.length,
    bySubject: Object.entries(bySubject).map(([subject, count]) => ({ subject, count })),
    recentlyAdded: Number(recentCount[0]?.count ?? 0),
  });
});

router.get("/questions/:id", async (req, res): Promise<void> => {
  const params = GetQuestionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [q] = await db.select().from(questionsTable).where(eq(questionsTable.id, params.data.id));
  if (!q) { res.status(404).json({ error: "Not found" }); return; }
  res.json(GetQuestionResponse.parse({
    ...q,
    options: q.options as string[],
    createdAt: q.createdAt.toISOString(),
  }));
});

router.patch("/questions/:id", async (req, res): Promise<void> => {
  const params = UpdateQuestionParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const body = UpdateQuestionBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }

  const updateData: Record<string, unknown> = {};
  if (body.data.subject != null) updateData.subject = body.data.subject;
  if (body.data.chapter != null) updateData.chapter = body.data.chapter;
  if (body.data.topic !== undefined) updateData.topic = body.data.topic;
  if (body.data.originalText != null) updateData.originalText = body.data.originalText;
  if (body.data.options != null) updateData.options = body.data.options;
  if (body.data.correctAnswer != null) updateData.correctAnswer = body.data.correctAnswer;
  if (body.data.explanation !== undefined) updateData.explanation = body.data.explanation;

  const [q] = await db.update(questionsTable).set(updateData).where(eq(questionsTable.id, params.data.id)).returning();
  if (!q) { res.status(404).json({ error: "Not found" }); return; }
  res.json({
    ...q,
    options: q.options as string[],
    createdAt: q.createdAt.toISOString(),
  });
});

router.delete("/questions/:id", async (req, res): Promise<void> => {
  const params = DeleteQuestionParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [q] = await db.delete(questionsTable).where(eq(questionsTable.id, params.data.id)).returning();
  if (!q) { res.status(404).json({ error: "Not found" }); return; }
  res.sendStatus(204);
});

export default router;
