import { Router, type IRouter } from "express";
import { db, studySessionsTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { CreateStudySessionBody, ListStudySessionsQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

function formatSession(s: any) {
  return {
    id: s.id,
    subject: s.subject,
    durationSeconds: s.durationSeconds,
    sessionType: s.sessionType,
    createdAt: s.createdAt.toISOString(),
  };
}

router.get("/studybloom/sessions", async (req, res): Promise<void> => {
  const parsed = ListStudySessionsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 50) : 50;

  const rows = await db
    .select()
    .from(studySessionsTable)
    .orderBy(desc(studySessionsTable.createdAt))
    .limit(limit);

  res.json(rows.map(formatSession));
});

router.post("/studybloom/sessions", async (req, res): Promise<void> => {
  const parsed = CreateStudySessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [session] = await db.insert(studySessionsTable).values(parsed.data).returning();
  res.status(201).json(formatSession(session));
});

router.get("/studybloom/stats", async (_req, res): Promise<void> => {
  const sessions = await db.select().from(studySessionsTable).orderBy(desc(studySessionsTable.createdAt));

  const totalSeconds = sessions.reduce((a, s) => a + s.durationSeconds, 0);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todaySeconds = sessions
    .filter(s => new Date(s.createdAt) >= today)
    .reduce((a, s) => a + s.durationSeconds, 0);

  // Streak: count consecutive days with sessions
  const daySet = new Set(
    sessions.map(s => new Date(s.createdAt).toISOString().slice(0, 10))
  );
  let streakDays = 0;
  const d = new Date();
  while (true) {
    const dateStr = d.toISOString().slice(0, 10);
    if (daySet.has(dateStr)) {
      streakDays++;
      d.setDate(d.getDate() - 1);
    } else {
      break;
    }
  }

  // By subject
  const subjectMap: Record<string, number> = {};
  for (const s of sessions) {
    const key = s.subject ?? "General";
    subjectMap[key] = (subjectMap[key] ?? 0) + s.durationSeconds;
  }

  res.json({
    totalSeconds,
    todaySeconds,
    streakDays,
    bySubject: Object.entries(subjectMap).map(([subject, totalSeconds]) => ({ subject, totalSeconds })),
    recentSessions: sessions.slice(0, 10).map(formatSession),
  });
});

export default router;
