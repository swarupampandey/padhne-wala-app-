import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, weakAreasTable, questionsTable } from "@workspace/db";
import {
  ListWeakAreasQueryParams,
  UpdateWeakAreaParams,
  UpdateWeakAreaBody,
  DeleteWeakAreaParams,
  CreateWeakAreaBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

function formatWeakArea(wa: any, q: any) {
  return {
    id: wa.id,
    questionId: wa.questionId,
    userId: wa.userId,
    studentNotes: wa.studentNotes,
    resolved: wa.resolved,
    subject: wa.subject,
    chapter: wa.chapter,
    createdAt: wa.createdAt.toISOString(),
    question: q ? {
      ...q,
      options: q.options as string[],
      createdAt: q.createdAt.toISOString(),
    } : null,
  };
}

router.post("/weak-areas", async (req, res): Promise<void> => {
  const parsed = CreateWeakAreaBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { subject, chapter, topic, questionText, correctAnswer, explanation, studentNotes, userId } = parsed.data;

  // Create a placeholder question for the manual entry
  const [q] = await db.insert(questionsTable).values({
    subject,
    chapter,
    topic: topic ?? null,
    originalText: questionText,
    options: [correctAnswer, "", "", ""],
    correctAnswer: 0,
    explanation: explanation ?? null,
    userId: userId ?? null,
    originalImageUrl: null,
    aiGeneratedImageUrl: null,
  }).returning();

  // Create the weak area
  const [wa] = await db.insert(weakAreasTable).values({
    questionId: q.id,
    userId: userId ?? null,
    subject,
    chapter,
    studentNotes: studentNotes ?? null,
    resolved: false,
  }).returning();

  res.status(201).json(formatWeakArea(wa, q));
});

router.get("/weak-areas", async (req, res): Promise<void> => {
  const parsed = ListWeakAreasQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { subject, resolved } = parsed.data;
  const conditions = [];
  if (subject) conditions.push(eq(weakAreasTable.subject, subject));
  if (resolved !== undefined && resolved !== null) {
    conditions.push(eq(weakAreasTable.resolved, resolved === "true"));
  }

  const rows = await db
    .select()
    .from(weakAreasTable)
    .leftJoin(questionsTable, eq(weakAreasTable.questionId, questionsTable.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(weakAreasTable.createdAt);

  res.json(rows.map(r => formatWeakArea(r.weak_areas, r.questions)));
});

router.get("/weak-areas/stats", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      subject: weakAreasTable.subject,
      chapter: weakAreasTable.chapter,
      count: sql<number>`count(*)`,
      resolved: sql<number>`sum(case when resolved then 1 else 0 end)`,
    })
    .from(weakAreasTable)
    .groupBy(weakAreasTable.subject, weakAreasTable.chapter)
    .orderBy(weakAreasTable.subject);

  res.json(rows.map(r => ({
    subject: r.subject,
    chapter: r.chapter,
    count: Number(r.count),
    resolved: Number(r.resolved),
  })));
});

router.patch("/weak-areas/:id", async (req, res): Promise<void> => {
  const params = UpdateWeakAreaParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const body = UpdateWeakAreaBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }

  const updateData: Record<string, unknown> = {};
  if (body.data.studentNotes !== undefined) updateData.studentNotes = body.data.studentNotes;
  if (body.data.resolved !== undefined && body.data.resolved !== null) updateData.resolved = body.data.resolved;

  const [wa] = await db.update(weakAreasTable).set(updateData).where(eq(weakAreasTable.id, params.data.id)).returning();
  if (!wa) { res.status(404).json({ error: "Not found" }); return; }

  const [q] = await db.select().from(questionsTable).where(eq(questionsTable.id, wa.questionId));
  res.json(formatWeakArea(wa, q));
});

router.delete("/weak-areas/:id", async (req, res): Promise<void> => {
  const params = DeleteWeakAreaParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [wa] = await db.delete(weakAreasTable).where(eq(weakAreasTable.id, params.data.id)).returning();
  if (!wa) { res.status(404).json({ error: "Not found" }); return; }
  res.sendStatus(204);
});

export default router;
