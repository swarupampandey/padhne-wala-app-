export default {
  plugins: {
    tailwindcss: {},
  },
};
