# NEET AI Suite Icon

This directory should contain the application icon files:

- `icon.ico` - Windows icon (256x256 recommended)
- `icon.png` - PNG icon for macOS/Linux (512x512 recommended)
- `icon.icns` - macOS icon bundle (if needed)

## Creating Icons

You can create icons using:
- Online tools like favicon.io or realfavicongenerator.net
- Design software like Figma, Adobe Illustrator, or GIMP
- Convert existing images using ImageMagick: `convert input.png -resize 256x256 icon.ico`

## Recommended Design
- Use the NEET AI Suite branding colors
- Include elements like brain, books, or medical symbols
- Keep it simple and recognizable at small sizes