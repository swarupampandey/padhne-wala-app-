import path from "path";
import { fileURLToPath } from "url";

/**
 * Get environment variable with optional default value
 */
export function getEnv(key: string, defaultValue?: string): string | undefined {
  return process.env[key] ?? defaultValue;
}

/**
 * Get required environment variable or throw
 */
export function getRequiredEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(
      `Missing required environment variable: ${key}. ` +
        `See .env.example for configuration details.`
    );
  }
  return value;
}

/**
 * Parse port number from env or use default
 */
export function getPort(defaultPort = 3000): number {
  const port = Number(process.env.PORT ?? defaultPort);
  if (Number.isNaN(port) || port <= 0) {
    throw new Error(
      `Invalid PORT: "${process.env.PORT}". Must be a positive integer.`
    );
  }
  return port;
}

/**
 * Get database URL with fallback to SQLite for development
 */
export function getDatabaseUrl(): string {
  const url = process.env.DATABASE_URL;

  // If explicitly provided, use it
  if (url && url.trim()) {
    return url;
  }

  // Development fallback: SQLite
  if (process.env.NODE_ENV !== "production") {
    const dataDir = path.join(
      path.dirname(fileURLToPath(import.meta.url)),
      "../../..",
      "data"
    );
    const dbPath = path.join(dataDir, "neet.db");
    return `file:${dbPath}`;
  }

  // Production: require PostgreSQL
  throw new Error(
    "DATABASE_URL is required in production. " +
      "Configure a PostgreSQL connection string."
  );
}

/**
 * API configuration for frontend
 */
export function getApiConfig() {
  return {
    baseUrl: process.env.VITE_API_BASE_URL || "/api",
    timeout: 30000,
  };
}

/**
 * AI Provider configuration
 */
export function getAiConfig() {
  return {
    gemini: {
      apiKey: process.env.GEMINI_API_KEY,
      enabled: !!process.env.GEMINI_API_KEY,
    },
    openai: {
      apiKey: process.env.OPENAI_API_KEY,
      enabled: !!process.env.OPENAI_API_KEY,
    },
    togetherAi: {
      apiKey: process.env.TOGETHER_AI_API_KEY,
      enabled: !!process.env.TOGETHER_AI_API_KEY,
    },
  };
}

/**
 * Check if we're in development mode
 */
export function isDevelopment(): boolean {
  return process.env.NODE_ENV !== "production";
}

/**
 * Application configuration (all combined)
 */
export function getAppConfig() {
  return {
    env: process.env.NODE_ENV || "development",
    port: getPort(),
    database: {
      url: getDatabaseUrl(),
      isDev: isDevelopment(),
    },
    api: getApiConfig(),
    ai: getAiConfig(),
    basePath: process.env.BASE_PATH || "/",
  };
}

export type AppConfig = ReturnType<typeof getAppConfig>;
