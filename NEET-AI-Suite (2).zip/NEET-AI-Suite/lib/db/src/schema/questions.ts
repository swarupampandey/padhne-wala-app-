import { pgTable, text, serial, timestamp, integer, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const questionsTable = pgTable("questions", {
  id: serial("id").primaryKey(),
  subject: text("subject").notNull(),
  chapter: text("chapter").notNull(),
  topic: text("topic"),
  originalText: text("original_text").notNull(),
  options: json("options").notNull().$type<string[]>(),
  correctAnswer: integer("correct_answer").notNull(),
  originalImageUrl: text("original_image_url"),
  aiGeneratedImageUrl: text("ai_generated_image_url"),
  explanation: text("explanation"),
  userId: text("user_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertQuestionSchema = createInsertSchema(questionsTable).omit({ id: true, createdAt: true });
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type Question = typeof questionsTable.$inferSelect;
