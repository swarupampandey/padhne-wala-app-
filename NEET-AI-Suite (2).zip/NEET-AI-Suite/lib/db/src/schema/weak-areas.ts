import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { questionsTable } from "./questions";

export const weakAreasTable = pgTable("weak_areas", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").notNull().references(() => questionsTable.id, { onDelete: "cascade" }),
  userId: text("user_id"),
  studentNotes: text("student_notes"),
  resolved: boolean("resolved").notNull().default(false),
  subject: text("subject").notNull(),
  chapter: text("chapter").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertWeakAreaSchema = createInsertSchema(weakAreasTable).omit({ id: true, createdAt: true });
export type InsertWeakArea = z.infer<typeof insertWeakAreaSchema>;
export type WeakArea = typeof weakAreasTable.$inferSelect;
